=== Imagina Login ===
Contributors: augusto97
Tags: login, custom login, login page, login customizer, dark mode
Requires at least: 6.1
Tested up to: 7.1
Stable tag: 2.4.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Personaliza el login de WordPress: 9 diseños, vista previa en vivo, modo oscuro, fondos con video o presentación y textos propios.

== Description ==

Transforma por completo la aburrida página de inicio de sesión de WordPress (`wp-login.php`) en una experiencia visualmente atractiva y coherente con tu identidad de marca. "Imagina Login" te permite tomar el control total del diseño sin necesidad de escribir una sola línea de código.

**Características principales:**

* **🎭 9 Diseños Profesionales:** Elige entre 9 templates modernos que se adaptan a diferentes estilos de marca:
  - Clásico Dos Columnas (empresas corporativas)
  - Sidebar Izquierda (variante invertida full height)
  - Sidebar 50/50 Derecha (diseño equilibrado)
  - Sidebar 50/50 Izquierda (balance con énfasis izquierdo)
  - Pantalla Dividida 60/40 (agencias creativas)
  - Pantalla Completa (aplicaciones web y SaaS)
  - Glassmorphism (startups tech y apps premium)
  - Sidebar Derecha (panel lateral full height)
  - Centrado Compacto (sitios minimalistas)
* **👁️ Vista Previa en Vivo:** Mira el login real mientras lo editas, en escritorio, tableta y móvil, sin guardar y sin cerrar tu sesión.
* **⚡ Diseños Rápidos:** 6 diseños completos (plantilla, fondo, colores y tipografía) que se aplican con un clic.
* **🖼️ Fondos Personalizables:** Color, degradado, imagen, video (subido, YouTube, Vimeo o enlace .mp4) o una presentación de imágenes con fundido.
* **🌙 Modo Oscuro:** Automático según el sistema del visitante o siempre activo, con logo alternativo para fondos oscuros.
* **🔤 Tipografías:** 10 fuentes de Google alojadas en tu propio sitio (sin conexiones a Google, compatible con RGPD).
* **✍️ Textos y Elementos:** Cambia etiquetas, botón, textos de ejemplo y mensaje de bienvenida; oculta "Recuérdame", "¿Olvidaste tu contraseña?" y otros enlaces.
* **🔒 Seguridad:** Mensaje de error genérico que no revela qué usuarios existen. Compatible con plugins de 2FA (Two Factor, WP 2FA, Wordfence y otros).
* **🎨 Sistema de Colores Completo:** Personaliza etiquetas, botones, enlaces y estados hover, o usa los colores de tu tema.
* **✨ Transiciones Animadas:** Fade, Slide Down o Zoom con velocidad y retraso independientes para logo y formulario.
* **📦 Importar y Exportar:** Lleva tu diseño a otro sitio o guarda una copia de seguridad en JSON.
* **🛠️ CSS Personalizado:** Para ajustes finos, con limpieza de seguridad.
* **🌍 Traducible:** En español, con traducción al inglés incluida y plantilla .pot para otros idiomas.
* **📱 100% Responsive y Accesible:** Funciona sin JavaScript, respeta "reducir movimiento" y muestra el foco al navegar con teclado.

Dale a tus usuarios y clientes una bienvenida profesional desde el primer momento con "Imagina Login".

== Installation ==

1.  Sube la carpeta `imagina-login` al directorio `/wp-content/plugins/` a través de FTP, o sube el archivo ZIP desde `Plugins > Añadir nuevo` en tu panel de WordPress.
2.  Activa el plugin a través del menú 'Plugins' en WordPress.
3.  Ve a **Ajustes > Imagina Login**, elige un diseño rápido o una plantilla y abre la **vista previa en vivo** para ver los cambios antes de guardar.

== Frequently Asked Questions ==

= ¿Dónde puedo configurar las imágenes de fondo? =

Una vez activado el plugin, encontrarás un nuevo menú en el panel de administración de WordPress llamado "Imagina Login". Desde ahí podrás subir la imagen para el fondo de la página y para el fondo del logo.

= ¿Qué logo se utiliza en el formulario? =

El plugin busca de forma inteligente el logo configurado en `Apariencia > Personalizar > Identidad del sitio`. Si tienes un "logo" lo usará, si no, buscará el "icono del sitio". Si no encuentra ninguno, mostrará el nombre de tu sitio como texto.

= ¿El plugin afectará la velocidad de mi sitio? =

No. Los estilos y scripts de este plugin solo se cargan en la página de `wp-login.php`, por lo que no afectan en absoluto al rendimiento del resto de tu web.

= ¿Es compatible con Multisite? =

Sí, el plugin funciona correctamente en instalaciones de WordPress Multisite.

== Screenshots ==

1.  El nuevo diseño de la página de login en acción, con fondo de página y fondo de logo personalizados.
2.  El panel de opciones para subir la imagen de fondo de la página (`body.login`).
3.  El panel de opciones para subir la imagen de fondo del área del logo (`div#login h1`).
4.  Vista del formulario de login en un dispositivo móvil, demostrando su diseño responsive.
5.  Ejemplo del selector de contraseña visible/oculto.

== Changelog ==

= 2.4.0 =
* 👁️ **NUEVO:** Vista previa en vivo del login real dentro del panel (escritorio, tableta y móvil), con los cambios sin guardar y sin cerrar la sesión. "Ver Login" ahora abre el login real.
* ⚡ **NUEVO:** 6 diseños rápidos de un clic.
* 🌙 **NUEVO:** Modo oscuro (automático o siempre) con logo alternativo.
* 🔤 **NUEVO:** 10 tipografías de Google alojadas en el propio sitio.
* 🖼️ **NUEVO:** Fondo con presentación de imágenes.
* ✍️ **NUEVO:** Textos de etiquetas, botón, textos de ejemplo y mensaje de bienvenida; error genérico de inicio de sesión; ocultar "Recuérdame", "¿Olvidaste tu contraseña?", "Ir al sitio" y privacidad; selector de idioma opcional; sin sacudida ni foco automático; enlace del logo.
* 📦 **NUEVO:** Importar y exportar ajustes en JSON.
* 🛠️ **NUEVO:** CSS personalizado.
* 🌍 **NUEVO:** Plugin traducible, con traducción al inglés y plantilla .pot.
* ♿ **MEJORA:** El aviso de Bloq Mayús de WordPress se muestra en lugar de ocultarse siempre; foco visible al navegar con teclado.
* 🐛 **FIX:** En móvil, el selector de idioma ensanchaba la tarjeta y sacaba el formulario de la pantalla.
* 🐛 **FIX:** Los controles del logo mostraban "200s" en lugar de "200px".
* 🧹 **CÓDIGO:** CSS y JS del panel en archivos propios (cacheables), constante IL_VERSION.

= 2.3.9 =
* 🔐 **FIX:** Compatibilidad con plugins de 2FA: el campo del código ya no aparece antes de introducir usuario y contraseña. El plugin forzaba a mostrarse los campos que esos plugins ocultan.
* 🔐 **FIX:** Se usa el botón de mostrar/ocultar contraseña de WordPress; antes se añadía a cualquier campo de contraseña, incluidos los de otros plugins.
* 🐛 **FIX:** "¿Olvidaste tu contraseña?" y "Registro" quedaban tapados por "Volver al sitio" en todos los diseños.
* 🐛 **FIX:** Sin JavaScript, el logo y el formulario quedaban invisibles y no se podía iniciar sesión.
* 🐛 **FIX:** Error fatal si el tema u otro plugin definía funciones comunes como custom_login_logo_url(); todas las funciones usan ahora el prefijo il_.
* 🐛 **FIX:** Los formularios de registro y de restablecer contraseña salían sin márgenes.
* 🐛 **FIX:** En Pantalla Completa y Glassmorphism las etiquetas y el botón eran invisibles con los colores por defecto.
* 🐛 **FIX:** 77 reglas CSS de los diseños nunca se aplicaban (pie, mensajes y enlaces).
* 🐛 **FIX:** Sin logo, el nombre del sitio aparecía duplicado.
* 🐛 **FIX:** El botón "Restaurar por Defecto" ahora funciona.
* 🎨 **MEJORA:** Estilos para el tooltip de "Recuérdame" (WordPress 7), los botones de otros plugins y el medidor de seguridad de la contraseña.
* 🔒 **SEGURIDAD:** Todos los ajustes se validan al guardarse y al leerse; un color manipulado ya no puede inyectar código en la página de login.
* ⚡ **RENDIMIENTO:** styles.css se descargaba dos veces; se quitó jQuery y dos observadores de la página de login.
* ⚡ **MEJORA:** La caché de estilos se renueva sola con cualquier cambio de ajustes (también desde WP-CLI).
* 🧹 **NUEVO:** uninstall.php borra los ajustes al desinstalar el plugin.

= 2.3.8 =
* 🎬 **NUEVO:** Video de fondo desde enlace externo: YouTube, Vimeo o archivo directo (.mp4, .webm)
* 🎬 **NUEVO:** El enlace externo tiene prioridad sobre el video subido; el panel indica si el enlace fue reconocido
* 🖼️ **NUEVO:** Subida manual del logo, con controles de ancho, alto, espacio vertical y borde separador
* ⚙️ **MEJORA:** Menú movido a Ajustes > Imagina Login
* 👁️ **FIX:** Botón "Ver Login" ahora muestra una vista previa real estando con sesión iniciada
* ⚡ **FIX:** Hooks de caché solo se registran en el admin

= 2.3.7 =
* 🐛 **FIX:** Corregido bug donde el layout no se guardaba en la primera selección
* 🐛 **FIX:** Cache de opciones ahora se limpia correctamente con added_option y updated_option
* 🐛 **FIX:** Variable estática de cache ahora se resetea correctamente al guardar
* 🎨 **MEJORA:** Panel de administración compactado - menos espacio vertical
* 🎨 **MEJORA:** Header, secciones, cards de templates y controles más compactos
* 🎨 **MEJORA:** Tabs de tipo de fondo ahora horizontales en vez de columnas
* 📦 **CÓDIGO:** Cache key actualizado a v10 para regeneración de estilos
* 📦 **ACTUALIZADO:** Versión del plugin a 2.3.7

= 2.3.6 =
* 🎛️ **NUEVO:** Controles separados para animaciones de Logo y Formulario
* ⚡ **NUEVO:** Control individual de velocidad para Logo (0.1 - 1.5s)
* ⚡ **NUEVO:** Control individual de delay para Logo (0 - 1.0s)
* ⚡ **NUEVO:** Control individual de velocidad para Formulario (0.1 - 1.5s)
* ⚡ **NUEVO:** Control individual de delay para Formulario (0 - 1.0s)
* 🎨 **MEJORA:** UI mejorada con secciones visuales separadas para cada animación
* 🎯 **FLEXIBILIDAD:** Personalización completa del timing de cada elemento
* 📦 **CÓDIGO:** Variables CSS actualizadas (--logo-duration, --logo-delay, --form-duration, --form-delay)
* 📦 **CÓDIGO:** Cache key actualizado a v9 para regeneración de estilos
* 📦 **ACTUALIZADO:** Versión del plugin a 2.3.6

= 2.3.5 =
* 🎬 **MEJORA MAYOR:** Transiciones completamente reoptimizadas con timings naturales
* ✨ **NUEVO:** Curvas de animación cubic-bezier para movimientos más fluidos y profesionales
* ⏱️ **OPTIMIZACIÓN:** Delays reducidos y sincronizados (150ms, 120ms, 100ms según tipo)
* 🎯 **MEJORA:** Movimientos más sutiles (20px en lugar de 30px, scale 0.95 en lugar de 0.9)
* 🎨 **MEJORA:** Duración de animaciones ajustada (80-90% de la duración base)
* 🎭 **MEJORA:** Efecto "bounce" sutil en animaciones con cubic-bezier(0.34, 1.56, 0.64, 1)
* ⚡ **PERFORMANCE:** Activación simultánea de animaciones a los 50ms (delays en CSS)
* 📦 **CÓDIGO:** Cache key actualizado a v8 para regeneración de estilos
* 📦 **ACTUALIZADO:** Versión del plugin a 2.3.5

= 2.3.4 =
* ✨ **MEJORA:** Restauradas animaciones individuales del logo y formulario con delays
* 🎨 **MEJORA:** Logo aparece con animación a los 100ms (fade + scale o slidedown o zoom)
* 🎨 **MEJORA:** Formulario aparece con animación a los 300ms (slide horizontal o vertical)
* 🎯 **BALANCE:** Fondo aparece inmediatamente (sin flash) + contenido con animaciones suaves
* 📦 **ACTUALIZADO:** Versión del plugin a 2.3.4

= 2.3.3 =
* 🚀 **OPTIMIZACIÓN MAYOR:** Refactorizado completamente el sistema de fondos
* 🐛 **FIX:** Eliminado flash visual de imagen al cargar - el fondo ahora aparece inmediatamente
* 🐛 **FIX:** Transiciones optimizadas - contenido aparece en 50ms en lugar de 500ms
* ⚡ **OPTIMIZACIÓN:** Eliminada duplicación de backgrounds entre body.login y ::after
* ⚡ **OPTIMIZACIÓN:** Removidas propiedades CSS redundantes de todos los templates
* 🎨 **MEJORA:** Sistema de clases simplificado (has-transitions, content-loaded)
* 🎨 **MEJORA:** Los fondos ya no se animan - aparecen instantáneamente
* 🎨 **MEJORA:** Solo el contenido del formulario se anima para mejor UX
* 📦 **CÓDIGO:** Estructura CSS más limpia y mantenible sin sobreescrituras
* 📦 **CÓDIGO:** Cache key actualizado a v7 para forzar regeneración de estilos
* 📦 **ACTUALIZADO:** Versión del plugin a 2.3.3

= 2.3.2 =
* 🐛 **FIX:** Resuelto scroll horizontal y vertical en sidebar templates alineados a la derecha
* 🐛 **FIX:** Eliminados gradientes hardcodeados - ahora todos controlables desde panel admin
* 🐛 **FIX:** Fondos de imagen ahora usan background-size: cover sin repetición
* 🐛 **FIX:** Removido flash de imagen de fallback antes de carga completa
* 🎨 **MEJORA:** Agregado !important para forzar background-size: cover en todos los templates
* 🎨 **MEJORA:** Consistencia de widths entre sidebar templates izquierdos y derechos
* 🎨 **MEJORA:** Todos los fondos de logo ahora personalizables vía CSS variables
* ⚡ **OPTIMIZACIÓN:** Removidos preloads de imágenes que causaban flash visual
* 📦 **ACTUALIZADO:** Versión del plugin a 2.3.2

= 2.3.1 =
* 🎨 **MEJORA:** Removidos templates muy similares (Centrado Minimalista y Logo Superior dejando solo Boxed)
* ✅ **NUEVO:** Sidebar Izquierda - variante invertida del sidebar con panel a la izquierda
* ✅ **NUEVO:** Sidebar 50/50 Derecha - diseño equilibrado con sidebar ocupando 50% del ancho
* ✅ **NUEVO:** Sidebar 50/50 Izquierda - diseño equilibrado con sidebar izquierdo
* 🐛 **FIX:** Template Full Screen ahora usa correctamente los fondos personalizables
* 🐛 **FIX:** Full Screen con backgrounds transparentes para mostrar fondo del body
* 🎨 **MEJORA:** Mejor visibilidad de labels y enlaces en Full Screen con text-shadow
* 🎨 **MEJORA:** Footer con backdrop-filter en Full Screen para mejor legibilidad
* 📱 **MEJORA:** Todas las variantes sidebar responsive (50% en desktop/tablet, 100% en móvil)
* 📦 **ACTUALIZADO:** Plugin ahora tiene 9 templates profesionales en total
* 📦 **ACTUALIZADO:** Versión del plugin a 2.3.1

= 2.3.0 =
* 🎭 **NUEVO:** 4 templates adicionales (ahora 8 en total)
* 🖥️ **NUEVO:** Template Pantalla Completa - login cubre toda la pantalla
* 💎 **NUEVO:** Template Glassmorphism - efecto cristal moderno
* 📱 **NUEVO:** Template Sidebar Lateral - panel lateral full height
* 📦 **NUEVO:** Template Centrado Compacto - caja flotante sobre fondo
* 🎨 **MEJORA:** Mockups visuales mejorados para todos los templates
* 🎨 **MEJORA:** Efectos backdrop-filter en template Glassmorphism
* 📱 **MEJORA:** Mejor experiencia responsive en todos los nuevos templates
* 🎨 **MEJORA:** Animaciones de entrada suaves en template Boxed
* 📦 **ACTUALIZADO:** Versión del plugin a 2.3.0

= 2.2.3 =
* 🎭 **NUEVO:** Sistema de templates con 4 diseños profesionales
* 🏢 **NUEVO:** Template Clásico Dos Columnas (mejorado del diseño original)
* ✨ **NUEVO:** Template Centrado Minimalista
* 🎯 **NUEVO:** Template Logo Superior
* 🎨 **NUEVO:** Template Pantalla Dividida 60/40
* ⚡ **OPTIMIZACIÓN:** Batch get_option() reduce queries de 13-18 a 1 sola
* ⚡ **OPTIMIZACIÓN:** Cache clearing consolidado de 25 hooks a 1 hook único
* ⚡ **OPTIMIZACIÓN:** MutationObserver con auto-disconnect después de 3s
* 🎨 **MEJORA:** Panel de administración reorganizado y más amigable
* 🎨 **MEJORA:** Selector visual de templates con preview animado
* 📦 **ACTUALIZADO:** Versión del plugin a 2.2.3

= 2.2.2 =
* Mejoras de compatibilidad y correcciones menores
* Sistema de transiciones mejorado

= 1.0.0 =
* ¡Lanzamiento inicial del plugin!
* Personalización de fondo para el body y el contenedor del logo
* Integración automática de logo y colores del tema
* Panel de administración para gestión de imágenes
* Diseño responsive

== Upgrade Notice ==

= 2.3.0 =
¡Actualización mayor! Ahora incluye 8 diseños profesionales incluyendo Full Screen, Glassmorphism, Sidebar y Boxed. Totalmente compatible con versiones anteriores.

= 2.2.3 =
Primera versión con sistema de templates múltiples y optimizaciones de rendimiento significativas. Totalmente compatible con versiones anteriores.

= 1.0.0 =
Esta es la primera versión del plugin. ¡Gracias por probarlo!